#include <iostream>
#include <stdlib.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <sys/msg.h>

#define SHMEM_SIZE 560

using namespace std;

int main(void)
{
    int shm_id;
    int sem_id;
    int msg_id;

    shm_id=shmget(IPC_PRIVATE,SHMEM_SIZE,IPC_CREAT | IPC_EXCL | 0600);

    if(shm_id==-1){
        cerr<<"Error shmget()"<<endl;
        return 1;
    }

    sem_id=semget(IPC_PRIVATE,1,IPC_CREAT | IPC_EXCL | 0600);

    if(sem_id==-1){
        cerr<<"Error semget()"<<endl;
        return 1;
    }

    msg_id=msgget(IPC_PRIVATE,IPC_CREAT | IPC_EXCL | 0600);

    if(msg_id==-1){
        cerr<<"Error msgget()"<<endl;
        return 1;
    }

    system("ipcs");

    cout<<"Press enter to continue ..."<<endl;
    cin.get();

    if(shmctl(shm_id,IPC_RMID,NULL)==-1){
        cerr<<"Error shmctl()"<<endl;
        return 1;
    }

    if(semctl(sem_id,1,IPC_RMID)==-1){
        cerr<<"Error semctl()"<<endl;
        return 1;
    }

    if(msgctl(msg_id,IPC_RMID,NULL)==-1){
        cerr<<"Error msgctl()"<<endl;
        return 1;
    }

    system("ipcs");

    return 0;
}
