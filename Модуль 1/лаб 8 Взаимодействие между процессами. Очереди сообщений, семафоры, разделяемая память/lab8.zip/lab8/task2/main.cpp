#include <stdio.h>
#include <cstring>
#include <string>
#include <sys/shm.h>
#include <sys/sem.h>
#include <iostream>
#include <cstdlib>

using namespace std;

#define SHMEM_SIZE   4096
#define SEM_KEY      700
#define SHM_KEY      700

union semnum {
    int val;
    struct semid_ds* buf;
    unsigned short * array;
} sem_arg;

int main (int argc, char ** argv){

    int shm_id, sem_id;
    char * shm_buf;
    int shm_size;
    struct shmid_ds ds;
    struct sembuf sb[1];
    unsigned short sem_vals[1];

    if(argc!=3){
        cerr<<"Incorrect data entry"<<endl;
        return 1;
    }

    int N=atoi(argv[2]);

    shm_id = shmget (SHM_KEY, SHMEM_SIZE,IPC_CREAT | IPC_EXCL | 0600);

    if (shm_id == -1) {
        cerr<<"Error shmget()"<<endl;
        return 1;
    }

    sem_id = semget (SEM_KEY, 1,0600 | IPC_CREAT | IPC_EXCL);

    if (sem_id == -1) {
        cerr<<"Error semget()"<<endl;
        return 1;
    }

    sem_vals[0] = 1;
    sem_arg.array = sem_vals;

    if (semctl (sem_id,0, SETALL, sem_arg) == -1) {
        cerr<<"Error semctl()"<<endl;
        return 1;
    }

    shm_buf = (char *) shmat (shm_id, NULL, 0);

    if (shm_buf == (char *) -1) {
        cerr<<"Error shmat()"<<endl;
        return 1;
    }

    if(shmctl (shm_id, IPC_STAT, &ds)==-1){
        cerr<<"Error shmctl()"<<endl;
        return 1;
    }

    shm_size = ds.shm_segsz;

    if (shm_size < strlen(argv[1])) {
        cerr<<"Error size"<<endl;
        return 1;
    }

    strcpy(shm_buf,argv[1]);

    sb[0].sem_num = 0;
    sb[0].sem_flg = SEM_UNDO;
    sb[0].sem_op = -1;

    if(semop (sem_id, sb, 1)==-1){
        cerr<<"Error semop()"<<endl;
        return 1;
    }

    for(int i=0;i<N/2;i++){
        sb[0].sem_op = -1;

        if(semop (sem_id, sb, 1)==-1){
            cerr<<"Error semop()"<<endl;
            return 1;
        }

        shm_buf = (char *) shmat (shm_id, 0, 0);

        if (shm_buf == (char *) -1) {
            cerr<<"Error shmat()"<<endl;
            return 1;
        }

        int old=atoi(shm_buf);
        string s=to_string(old+1);
        const char *p=s.c_str();
        strcpy(shm_buf,p);

        cout<<"Число с памяти:"<<old<<" Число, помещенное в память:"<<s<<endl;

        if(N%2==0 && i==N/2-1){
            strcpy(shm_buf,"exit");

            if(semctl (sem_id, 1, IPC_RMID, sem_arg)==-1){
                cerr<<"Error semctl()"<<endl;
                return 1;
            }

            if(shmdt (shm_buf)==-1){
                cerr<<"Error shmdt()"<<endl;
                return 1;
            }

            if(shmctl (shm_id, IPC_RMID, NULL)==-1){
                cerr<<"Error shmctl()"<<endl;
                return 1;
            }

            return 0;
        }
    }

    sb[0].sem_op = -1;

    if(semop (sem_id, sb, 1)==-1){
        cerr<<"Error semop()"<<endl;
        return 1;
    }

    shm_buf = (char *) shmat (shm_id, 0, 0);

    if (shm_buf == (char *) -1) {
        cerr<<"Error shmat()"<<endl;
        return 1;
    }

    strcpy(shm_buf,"exit");

    if(semctl (sem_id, 1, IPC_RMID, sem_arg)==-1){
        cerr<<"Error semctl()"<<endl;
        return 1;
    }

    if(shmdt (shm_buf)==-1){
        cerr<<"Error shmdt()"<<endl;
        return 1;
    }

    if(shmctl (shm_id, IPC_RMID, NULL)==-1){
        cerr<<"Error shmctl()"<<endl;
        return 1;
    }

    return 0;
}
