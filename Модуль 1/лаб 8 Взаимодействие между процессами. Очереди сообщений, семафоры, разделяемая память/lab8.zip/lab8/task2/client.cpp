#include <sys/shm.h>
#include <stdio.h>
#include <sys/sem.h>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <string>

#define SEM_KEY 700
#define SHM_KEY 700

using namespace std;

int main (void){

int shm_id, sem_id;
char * shm_buf;
struct sembuf sb[1];

shm_id = shmget (SHM_KEY, 1, 0600);

if (shm_id == -1) {
    cerr<<"Error shmget()"<<endl;
    return 1;
}

sem_id = semget (SEM_KEY, 1, 0600);

if (sem_id == -1) {
    cerr<<"Error semget()"<<endl;
    return 1;
}

for(;;){

    shm_buf = (char *) shmat (shm_id, 0, 0);

    if (shm_buf == (char *) -1) {
        cerr<<"Error shmat()"<<endl;
        return 1;
    }

    if(strcmp(shm_buf,"exit")==0){
        break;
    }

    int old=atoi(shm_buf);
    string s=to_string(old+1);
    const char *p=s.c_str();
    strcpy(shm_buf,p);

    cout<<"Число с памяти:"<<old<<" Число, помещенное в память:"<<s<<endl;

    sb[0].sem_num = 0;
    sb[0].sem_flg = SEM_UNDO;
    sb[0].sem_op = 1;

    if(semop (sem_id, sb, 1)==-1){
        cerr<<"Error semop()"<<endl;
        return 1;
    }
}

if(shmdt (shm_buf)==-1){
    cerr<<"Error shmdt()"<<endl;
    return 1;
}

return 0;
}
