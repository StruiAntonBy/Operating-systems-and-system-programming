#include <iostream>
#include <pthread.h>
#include <unistd.h>
#include <stdlib.h>

using namespace std;

static int meat;
static bool call_chef=false;

pthread_mutex_t mut;
pthread_cond_t cond;

struct var{
    int number;
};

void *funcChef(void *arg){
    int M=*(int*) arg;

    for(;;){
        if(pthread_mutex_lock(&mut)!=0){
            cerr<<"Error pthread_mutex_lock()"<<endl;
            exit(1);
        }

        while(meat!=0){
            pthread_cond_wait(&cond,&mut);
        }

        cerr<<"Повар готовит обед"<<endl;
        sleep(5);
        meat=M;
        call_chef=false;

        if(pthread_mutex_unlock(&mut)!=0){
            cerr<<"Error pthread_mutex_unlock()"<<endl;
            exit(1);
        }
    }
}

void *funcBarbarian(void *arg){
    struct var v=*(var*) arg;

    for(;;){
        if(pthread_mutex_lock(&mut)!=0){
            cerr<<"Error pthread_mutex_lock()"<<endl;
            exit(1);
        }

        if(meat==0 && call_chef==false){
            cerr<<"Дикарь "<<v.number<<" будит повара"<<endl;
            sleep(5);
            call_chef=true;

            if(pthread_mutex_unlock(&mut)!=0){
                cerr<<"Error pthread_mutex_unlock()"<<endl;
                exit(1);
            }

            pthread_cond_signal(&cond);
        }
        else if(call_chef){
            if(pthread_mutex_unlock(&mut)!=0){
                cerr<<"Error pthread_mutex_unlock()"<<endl;
                exit(1);
            }
        }
        else{
            meat=meat-1;

            if(pthread_mutex_unlock(&mut)!=0){
                cerr<<"Error pthread_mutex_unlock()"<<endl;
                exit(1);
            }

            cerr<<"Дикарь "<<v.number<<" съел мясо"<<endl;
            sleep(2);
        }
    }
}

int main(void)
{
    int N,M;
    pthread_t chef;

    cerr<<"Для выхода из программы введите 1"<<endl;

    cerr<<"Введите количество дикарей:";
    cin>>N;

    cerr<<"Введите количество мяса, которое помещается в горшок:";
    cin>>M;

    if(N<=0 || M<=0){
        cerr<<"Error data"<<endl;
        return 1;
    }

    meat=M;

    if(pthread_mutex_init(&mut, NULL)!=0){
        cerr<<"Error pthread_mutex_init()"<<endl;
        return 1;
    }

    if(pthread_cond_init(&cond, NULL)!=0){
        cerr<<"Error pthread_cond_init()"<<endl;
        return 1;
    }

    pthread_t *barbarians=new pthread_t[N];
    var *v;

    for(int i=0;i<N;i++){
        v=new var;
        v->number=i+1;

        if(pthread_create(&barbarians[i],NULL,funcBarbarian,(void*)v)!=0){
            cerr<<"Error pthread_create()"<<endl;
            return 1;
        }

        if(pthread_detach(barbarians[i])!=0){
            cerr<<"Error pthread_detach()"<<endl;
            return 1;
        }
    }

    if(pthread_create(&chef,NULL,funcChef,&M)!=0){
        cerr<<"Error pthread_create()"<<endl;
        return 1;
    }

    if(pthread_detach(chef)!=0){
        cerr<<"Error pthread_detach()"<<endl;
        return 1;
    }

    for(;;){
        cin>>M;
        if(M==1){
            break;
        }
    }

    for(int i=0;i<N;i++){
        if(pthread_cancel(barbarians[i])!=0){
            cerr<<"Error pthread_cancel()"<<endl;
            return 1;
        }
    }

    if(pthread_cancel(chef)!=0){
        cerr<<"Error pthread_cancel()"<<endl;
        return 1;
    }

    pthread_cond_destroy(&cond);
    pthread_mutex_destroy(&mut);

    delete [] barbarians;

    return 0;
}
