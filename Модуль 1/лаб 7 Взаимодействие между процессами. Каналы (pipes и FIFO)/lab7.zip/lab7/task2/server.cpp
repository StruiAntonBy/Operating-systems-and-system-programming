#include <iostream>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/types.h>
#include <cstring>
#include <cctype>

#define FIFO_NAME "PipeFifo"
#define BUF_SIZE 4096

using namespace std;

int main(void){

    char buffer[BUF_SIZE];

    if(mkfifo(FIFO_NAME,0640)==-1){
        cerr<<"Failed to create a FIFO file"<<endl;
        return 1;
    }
    
    int fd_FIFO=open(FIFO_NAME,O_RDONLY);
    
    if(fd_FIFO==-1){
        cerr<<"Failed to open the FIFO file"<<endl;
        return 1;
    }

    bool flag=false;

    for(;;){
        while(read(fd_FIFO, buffer, BUF_SIZE)>0){
            flag=true;
        }
        if(flag){
            break;
        }
    }

    if(close(fd_FIFO)==-1){
        cerr<<"Error close FIFO file"<<endl;
        return 1;
    }

    fd_FIFO=open(FIFO_NAME,O_WRONLY);

    if(fd_FIFO==-1){
        cerr<<"Failed to open the FIFO file"<<endl;
        return 1;
    }

    flag=true;

    for(int i=0;i<BUF_SIZE;i++){
        if(buffer[i]==' '){
            flag=true;
        }
        else if(flag){
            buffer[i]=toupper(buffer[i]);
            flag=false;
        }
    }

    if(write(fd_FIFO,buffer,strlen(buffer)+1)==-1){
        cerr<<"Failed to write to the FIFO file"<<endl;
        return 1;
    }

    if(close(fd_FIFO)==-1){
        cerr<<"Error close FIFO file"<<endl;
        return 1;
    }

    return 0;
}
