#include <iostream>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/types.h>
#include <string>
#include <cstring>

#define FIFO_NAME "PipeFifo"

using namespace std;

int main(void)
{
    int fd_FIFO=open(FIFO_NAME,O_WRONLY);

    if(fd_FIFO==-1){
        cerr<<"Failed to open the FIFO file"<<endl;
        return 1;
    }

    string str;

    cout<<"Введите строку:";
    getline(cin,str);
    
    int n=str.length();
    char s[n];
    
    for(int i=0;i<n;i++){
        s[i]=str[i];
    }

    if(write(fd_FIFO,s,strlen(s)+1)==-1){
        cerr<<"Failed to write to the FIFO file"<<endl;
        return 1;
    }

    if(close(fd_FIFO)==-1){
        cerr<<"Error close FIFO file"<<endl;
        return 1;
    }

    fd_FIFO=open(FIFO_NAME,O_RDONLY);

    if(fd_FIFO==-1){
        cerr<<"Failed to open the FIFO file"<<endl;
        return 1;
    }

    bool flag=false;

    for(;;){
        while(read(fd_FIFO, s,strlen(s)+1)>0){
            flag=true;
        }
        if(flag){
            break;
        }
    }

    string strserver=string(s);
    cout<<"Server:"<<strserver<<endl;

    if(close(fd_FIFO)==-1){
        cerr<<"Error close FIFO file"<<endl;
        return 1;
    }

    if(unlink(FIFO_NAME)==-1){
        cerr<<"Error unlink FIFO file"<<endl;
        return 1;
    }

    return 0;
}
