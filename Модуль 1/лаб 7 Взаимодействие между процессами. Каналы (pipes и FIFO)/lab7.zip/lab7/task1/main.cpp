#include <iostream>
#include <unistd.h>
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>

using namespace std;

int fifo[2]; /* 0 - read, 1 - write */

void func1 (void){
    char *argv[] = { "/bin/w", NULL };

    dup2 (fifo[1], STDOUT_FILENO);
    close (fifo[0]);
    execvp (argv[0], argv);
    cerr<<"Eror w"<<endl;
    return;
}

void func2 (void){
    char *argv[] = { "/bin/more", NULL };

    dup2 (fifo[0], STDIN_FILENO);
    close (fifo[1]);
    execvp (argv[0], argv);
    cerr<<"Eror more"<<endl;
    return;
}

int main (void){
    pid_t status,childpid;
    int exit_status;

    if (pipe (fifo)==-1){
        cerr<<"Eror pipe"<<endl;
    }

    status=fork();

    if(status==-1){
        cerr<<"Error fork"<<endl;
        return 1;
    }

    if (status == 0){
        func1 ();
    }

    childpid=wait(&exit_status);

    if(WIFEXITED(exit_status)){
        func2 ();
    }

    close (fifo[0]);
    close (fifo[1]);

    return 0;
}
