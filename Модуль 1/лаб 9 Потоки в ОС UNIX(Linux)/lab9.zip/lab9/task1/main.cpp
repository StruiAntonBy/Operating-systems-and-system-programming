#include <iostream>
#include <unistd.h>
#include <pthread.h>

using namespace std;

void * func1(void * args){
    for(;;){
        cerr<<"A";
        sleep(5);
    }
    return NULL;
}

void * func2(void * args){

    pthread_t thread=* (pthread_t *) args;

    for(int i=0;i<20;i++){
        cerr<<"B";
        sleep(5);
    }

    if(pthread_join(thread,NULL)!=0){
        cerr<<"Error"<<endl;
    }

    return NULL;
}

int main(void)
{
    pthread_t thread1,thread2;
    int result;

    if(pthread_create(&thread1,NULL,&func1,NULL)!=0){
        cerr<<"Error pthread_create()"<<endl;
        return 1;
    }

    if(pthread_create(&thread2,NULL,&func2,&thread1)!=0){
        cerr<<"Error pthread_create()"<<endl;
        return 1;
    }

    sleep(110);

    pthread_cancel(thread2);

    if(!pthread_equal(pthread_self(),thread2)){

        if(pthread_join(thread2,NULL)!=0){
            cerr<<"Error pthread_join()"<<endl;
            return 1;
        }

    }

    return 0;
}
