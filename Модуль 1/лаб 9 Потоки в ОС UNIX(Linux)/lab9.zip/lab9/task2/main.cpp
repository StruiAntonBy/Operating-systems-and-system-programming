#include <iostream>
#include <fstream>
#include <pthread.h>
#include <unistd.h>
#include <cstdlib>

using namespace std;

int sum=0;
int K,N;
int **A;

struct array_arg{
    int *mas;
    int N;
};

void showMatrix(){
    for(int i=0;i<K;i++){
        for(int j=0;j<K;j++){
            cerr<<A[i][j]<<" ";
        }
        cerr<<endl;
    }
}

int lenArray(int start){
    start=start+N;
    int j=1;
        
    while(start<K){
        start=start+N;
        j++;
    }

    return j;
}

void * func(void * arg){
    struct array_arg argc=*(array_arg*) arg;
    
    for(int i=0;i<argc.N;i++){
        
        int line=argc.mas[i];
        
        for(int column=0;column<K;column++){

            if(line==0 && column==0){
                if(A[line][column]>A[line+1][column+1] && A[line][column]>A[line+1][column] && A[line][column]>A[line][column+1]){
                    sum=sum+1;
                }
            }
            
            else if(line==K-1 && column==K-1){
                if(A[line][column]>A[line-1][column-1] && A[line][column]>A[line-1][column] && A[line][column]>A[line][column-1]){
                    sum=sum+1;
                }
            }
            
            else if(line==K-1 && column==0){
                if(A[line][column]>A[line-1][column+1] && A[line][column]>A[line-1][column] && A[line][column]>A[line][column+1]){
                    sum=sum+1;
                }
            }
            
            else if(line==0 && column==K-1){
                if(A[line][column]>A[line+1][column-1] && A[line][column]>A[line+1][column] && A[line][column]>A[line][column-1]){
                    sum=sum+1;
                }
            }
            
            else if(line==0){
                if(A[line][column]>A[line+1][column-1] && A[line][column]>A[line+1][column+1] && A[line][column]>A[line+1][column] && A[line][column]>A[line][column+1] && A[line][column]>A[line][column-1]){
                    sum=sum+1;
                }
            }
            
            else if(line==K-1){
                if(A[line][column]>A[line-1][column-1] && A[line][column]>A[line-1][column+1] && A[line][column]>A[line-1][column] && A[line][column]>A[line][column+1] && A[line][column]>A[line][column-1]){
                    sum=sum+1;
                }
            }
            
            else if(column==0){
                if(A[line][column]>A[line-1][column+1] && A[line][column]>A[line+1][column+1] && A[line][column]>A[line][column+1] && A[line][column]>A[line+1][column] && A[line][column]>A[line-1][column]){
                    sum=sum+1;
                }
            }
            
            else if(column==K-1){
                if(A[line][column]>A[line-1][column-1] && A[line][column]>A[line+1][column-1] && A[line][column]>A[line][column-1] && A[line][column]>A[line+1][column] && A[line][column]>A[line-1][column]){
                    sum=sum+1;
                }
            }
            
            else{
                if(A[line][column]>A[line-1][column-1] && A[line][column]>A[line-1][column+1] && A[line][column]>A[line+1][column+1] && A[line][column]>A[line][column+1] && A[line][column]>A[line+1][column-1] && A[line][column]>A[line][column-1] && A[line][column]>A[line+1][column] && A[line][column]>A[line-1][column]){
                    sum=sum+1;
                }
            }
        }
    }

    pthread_exit(NULL);
}

int main(void){
    
    cout<<"Введите размерность матрицы:";
    cin>>K;
    cout<<"Введите количество потоков:";
    cin>>N;
    
    if(N>K || N<=0 || K<=0){
        cerr<<"Incorrect data entry"<<endl;
        return 1;
    }

    A=new int *[K];

    for(int i=0;i<K;i++){
        A[i]=new int [K];
    }
    
    int q;
    
    cerr<<"Введите 1 если хотите прочитать матрицу из файла."<<endl;
    cerr<<"Введите 2 если хотите сгенерировать матрицу случайным образом."<<endl;
    cin>>q;
    
    if(q==1){
        ifstream in("input.txt");

        if(in.is_open()){
            for(int i=0;i<K;i++){
                for(int j=0;j<K;j++){
                    in>>A[i][j];
                }
            }
            in.close();
        }
        else{
            cerr<<"Error open file"<<endl;
            return 1;
        }
    }
    else if(q==2){
        for(int i=0;i<K;i++){
            for(int j=0;j<K;j++){
                A[i][j]=rand()%10;
            }
        }
    }
    
    cerr<<"Матрица:"<<endl;
    showMatrix();
    
    if(K==1){
        
        cerr<<"Количество локальных максимумов:"<<1<<endl;
        
        for(int i=0;i<K;i++){
            delete [] A[i];
        }

        delete [] A;

        return 0;
    }

    pthread_t thread;
    array_arg *arg;
    
    for(int i=0;i<N;i++){
        arg=new array_arg;
        int Size_Array=lenArray(i);
        
        arg->mas=new int [Size_Array];
        arg->N=Size_Array;

        arg->mas[0]=i;
        
        int line=i+N;
        int j=1;
        
        while(line<K){
            arg->mas[j]=line;
            line=line+N;
            j++;
        }

        if(pthread_create(&thread,NULL,func,(void *)arg)!=0){
            cerr<<"Error pthread_create()"<<endl;
            return 1;
        }
        
        if(pthread_detach(thread)!=0){
            cerr<<"Error pthread_detach()"<<endl;
            return 1;
        }

    }
    
    sleep(5);
    cerr<<"Количество локальных максимумов:"<<sum<<endl;

    for(int i=0;i<K;i++){
        delete [] A[i];
    }

    delete [] A;

    return 0;
}
